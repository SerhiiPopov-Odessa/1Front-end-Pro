import { cn } from "@/lib/utils"
import { Title } from "./title"
import { FilterCheckbox } from "./filter-checkbox"
import { Input } from "../ui/input"
import { RangeSlider } from "./range-slider"
import { CheckboxFiltersGroup } from "./checkbox-filters-group"

type FiltersProps = {
  className?: string
}

export  function Filters({ className }: FiltersProps) {
  return (
    <div className={cn("", className)}>
        <Title text="Фильтрация" size="sm" className="mb-5 font-bold" />

        {/* Верхние чекбоксы */}
        <div className="flex flex-col gap-4">
            <FilterCheckbox text="Можно собирать" value="1"/>
            <FilterCheckbox text="Новинки" value="2"/>
        </div>

        {/* Вильтр цен */}
        <div className="mt-5 border-y border-y-neutral-100 py-6 pb-7">
            <p className="font-bold mb-3">Цена от и до:</p>
            <div className="flex gap-3 mb-5">
                <Input type="number" placeholder="0" min={0} max={30000} defaultValue={0} />
                <Input type="number" placeholder="30000" min={100} max={30000}  />
            </div>
            <RangeSlider min={0} max={5000} step={10} value={[0,5000]}/>
        </div>

        <CheckboxFiltersGroup
        title="Ингредиенты"
        name="ingredients"
        className="mt-5"
        limit={5}
        defaultItems={[
          {
            text:'Сырный соус',
            value:'1'
          },
          {
            text:'Моццарелла',
            value:'2'
          },
          {
            text:'Чеснок',
            value:'3'
          },
          {
            text:'Солённые огурчики',
            value:'4'
          },
          {
            text:'Красный лук',
            value:'5'
          },
          {
            text:'Томаты',
            value:'6'
          },
        ]}
        items={[
          {
            text:'Сырный соус',
            value:'1'
          },
          {
            text:'Моццарелла',
            value:'2'
          },
          {
            text:'Чеснок',
            value:'3'
          },
          {
            text:'Солённые огурчики',
            value:'4'
          },
          {
            text:'Красный лук',
            value:'5'
          },
          {
            text:'Томаты',
            value:'6'
          },
        ]}

        /* defaultItems={items.slice(0, 6)}
        items={items}
        loading={loading}
        onClickCheckbox={filters.setSelectedIngredients}
        selected={filters.selectedIngredients} */
      />
    </div>
  )
}